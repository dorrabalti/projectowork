#include <gtk/gtk.h>


void
on_button_ajout_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_type_3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_type_2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sexe_hm_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sexe_fm_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ok_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_sexe_hm_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_sexe_fm_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_affiche_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_recherche_nehdi_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_Modif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_search_clicked               (GtkButton       *button,
                                        gpointer         user_data);
