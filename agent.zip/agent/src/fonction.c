#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"
#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"


enum
{
NOM,
PRENOM,
CIN,
EMAIL,
NIV,
TYPECHAMBRE,
NUMCHAMBRE,
TELE,
SEXE,
JOUR,
MOIS,
ANNEE,
COLUMNS
};



enum 
{ 
    
	NOM1,
	PRENOM1,
	CIN1,
	EMAIL1,
	NIV1,
	TYPECHAMBRE1,
	NUMCHAMBRE1,
	TELE1,
	SEXE1,
	JOUR1,
	MOIS1,
	ANNEE1,
	COLUMNS1
};

void add_etudiant(etudiant e)
{
FILE* f=NULL;
f=fopen("etudiant.txt","a+");
fprintf(f,"%s %s %s %s %s %s %s %s %s %d %d %d\n",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,e.d.jour,e.d.mois,e.d.annee);
fclose(f);
}

void afficher_resultat(GtkWidget *liste)
{	etudiant e;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	FILE *f ;

	
	store=NULL;
	
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("prenom",renderer,"text",PRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("CIN",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("email",renderer,"text",EMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
		
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("niveau",renderer,"text",NIV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("type_chambre",renderer,"text",TYPECHAMBRE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("num_chambre",renderer,"text",NUMCHAMBRE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("num_tele",renderer,"text",TELE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("sexe",renderer,"text",SEXE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",JOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",MOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",ANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);
	
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);	

	f=fopen("etudiant.txt","a+");
	if(f==NULL)
	
		printf("erreur ");
	
	else
	{
	while((fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,&e.d.jour,&e.d.mois,&e.d.annee))!=EOF)
	{
	
		
		gtk_list_store_append (store,&iter);
		gtk_list_store_set (store,&iter,NOM,e.nom,PRENOM,e.prenom,CIN,e .CIN,EMAIL,e.email,NIV,e.niv,TYPECHAMBRE,e.type_chambre,NUMCHAMBRE,e.num_chambre,TELE,e.num_tele,SEXE,e.sexe,JOUR,e.d.jour,MOIS,e.d.mois,ANNEE,e.d.annee, -1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
}
}

void delete_etudiant(char pr[])
{
FILE*f=NULL;
FILE*f1=NULL;
etudiant e ;
f=fopen("etudiant.txt","r");
f1=fopen("ancien.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d ",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,&e.d.jour,&e.d.mois,&e.d.annee)!=EOF)
{
if(strcmp(pr,e.prenom)!=0)
fprintf(f1,"%s %s %s %s %s %s %s %s %s %d %d %d\n",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,e.d.jour,e.d.mois,e.d.annee);

fclose(f);
fclose(f1);
}
remove("etudiant.txt");
rename("ancien.txt","etudiant.txt");
}


void update_etudiant(char CIN[],newe ne)
{
etudiant e;
FILE *f=NULL;
FILE *f1=NULL;
f=fopen("etudiant.txt","r");
f1=fopen("ancien.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d ",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,&e.d.jour,&e.d.mois,&e.d.annee)!=EOF)
{
if(strcmp(ne.cinnew,e.CIN)==0) 
{	
fprintf(f1,"%s %s %s %s %s %s %s %s %s %d %d %d\n",e.nom,e.prenom,e.CIN,ne.emailnew,ne.nivnew,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,e.d.jour,e.d.mois,e.d.annee);
}
else

{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %d %d %d\n",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,e.d.jour,e.d.mois,e.d.annee);
}
}
fclose(f);
fclose(f1);

remove("etudiant.txt");
rename("ancien.txt","etudiant.txt");
}



/*void search_etudiant(char pr[])
{
FILE* f=NULL;
FILE* f2=NULL;
etudiant e;
f=fopen("etudiant.txt","r");
f2=fopen("recherche_etudiant.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,&e.d.jour,&e.d.mois,&e.d.annee)!=EOF)
{
if(strcmp(pr,e.prenom)==0)
fprintf(f2,"%s %s %s %s %s %s %s %s %s %d %d %d\n",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,e.d.jour,e.d.mois,e.d.annee);
}
fclose(f);
fclose(f2);
}
*/


/*void afficher_recherche(GtkWidget *liste )
{ 
etudiant e;
GtkCellRenderer *renderer1;
GtkTreeViewColumn *column1;
GtkTreeIter iter1;
GtkListStore *store1;
FILE *f ;

store1=NULL;

store1=gtk_tree_view_get_model(liste);

if(store1==NULL)
{
renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("nom",renderer1,"text",NOM1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("prenom",renderer1,"text",PRENOM1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("CIN",renderer1,"text",CIN1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("email",renderer1,"text",EMAIL1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);



renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("niveau",renderer1,"text",NIV1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("type_chambre",renderer1,"text",TYPECHAMBRE1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);


renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("num_chambre",renderer1,"text",NUMCHAMBRE1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("num_tele",renderer1,"text",TELE1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("sexe",renderer1,"text",SEXE1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("jour",renderer1,"text",JOUR1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("mois",renderer1,"text",MOIS1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);

renderer1=gtk_cell_renderer_text_new ();
column1=gtk_tree_view_column_new_with_attributes ("annee",renderer1,"text",ANNEE1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column1);



store1=gtk_list_store_new (COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);	


f=fopen("recherche_etudiant.txt","r");
if(f==NULL)

printf("erreur");

else
{
f=fopen("recherche_etudiant.txt","a+");
while((fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,&e.d.jour,&e.d.mois,&e.d.annee))!=EOF)
{


gtk_list_store_append (store1,&iter1);
gtk_list_store_set (store1,&iter1,NOM1,e.nom,PRENOM1,e.prenom,CIN1,e.CIN,EMAIL1,e.email,NIV1,e.niv,TYPECHAMBRE1,e.type_chambre,NUMCHAMBRE1,e.num_chambre,TELE1,e.num_tele,SEXE1,e.sexe,JOUR1,e.d.jour,MOIS1,e.d.mois,ANNEE1,e.d.annee,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store1));
g_object_unref(store1);

}
}
}
*/
