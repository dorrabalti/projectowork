#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include<stdio.h>
#include<gtk/gtk.h>
#include<string.h>
#include"callbacks.h"
#include"interface.h"
#include"support.h"
#include"fonction.h"
#include<stdlib.h>
int x=1;
int t;

void
on_radiobutton_sexe_hm_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=1;
}


void
on_radiobutton_sexe_fm_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=2;
}

void
on_button_ajout_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *entry_nom;
GtkWidget *entry_prenom;
GtkWidget *entry_cin;
GtkWidget *entry_email;
GtkWidget *entry_tel;
GtkWidget *combobox_type;
GtkWidget *combobox_niv;
GtkWidget *combobox_chambre;
GtkWidget *spinbutton_jour;
GtkWidget *spinbutton_mois;
GtkWidget *spinbutton_annee;
GtkWidget *output;
GtkWidget *ajout_etudiant;
GtkWidget *msg;

ajout_etudiant=lookup_widget(button,"window1");


char sexeoutput[50];
char text[100]="";
char texte1[100]="";
char texte2[100]="";
if(x==1)
strcpy(e.sexe,"homme");
else
if(x==2)
strcpy(e.sexe,"femme");



entry_nom=lookup_widget(button,"entry_nom");
entry_prenom=lookup_widget(button,"entry_prenom");
entry_cin=lookup_widget(button,"entry_cin");
entry_email=lookup_widget(button,"entry_email");
entry_tel=lookup_widget(button,"entry_tel");

strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entry_nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(entry_prenom)));
strcpy(e.CIN,gtk_entry_get_text(GTK_ENTRY(entry_cin)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(entry_email)));
strcpy(e.num_tele,gtk_entry_get_text(GTK_ENTRY(entry_tel)));

combobox_type=lookup_widget(button,"combobox_type");
combobox_niv=lookup_widget(button,"combobox_niv");
combobox_chambre=lookup_widget(button,"combobox_chambre");

strcpy(e.type_chambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_type)));
strcpy(e.niv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_niv)));
strcpy(e.num_chambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_chambre)));


spinbutton_jour=lookup_widget(button,"spinbutton_jour");
spinbutton_mois=lookup_widget(button,"spinbutton_mois");
spinbutton_annee=lookup_widget(button,"spinbutton_annee");

e.d.jour=(gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton_jour)));
e.d.mois=(gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton_mois)));
e.d.annee=(gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbutton_annee)));



add_etudiant(e);

/*
if(r==1)

sprintf(text,"ajout avec succes");
else 
sprintf(text,"ajout !!!");
output=lookup_widget(button,"label44");
gtk_label_set_text(GTK_LABEL(output),text);*/
}

















void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* cin;
gchar* email;
gchar* niv;
gchar* typechambre;
gchar* numchambre;
gchar* numtele;
gchar* sexe;
gchar* jour;
gchar* mois;
gchar* annee;
etudiant e;
char pr[50];

        GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
//obtention de valeur de la ligne selectionne
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,nom,1,prenom,2,cin,3,email,4,&niv,5,&typechambre,6,&numchambre,7,&numtele,8,&sexe,9,&jour,10,mois,11,annee);
//copier de valeur dans la variable m
strcpy(e.nom,nom);
strcpy(e.prenom,prenom);
strcpy(e.CIN,cin);
strcpy(e.email,email);
strcpy(e.niv,niv);
strcpy(e.type_chambre,typechambre);
        strcpy(e.num_chambre,numchambre);
        strcpy(e.num_tele,numtele);
strcpy(e.sexe,sexe);
strcpy(e.d.jour,jour);
strcpy(e.d.mois,mois);
strcpy(e.d.annee,annee);
delete_etudiant(pr);
//appelle a la fonction afficher
afficher_resultat(treeview);

}
}

void
on_button_affiche_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
//GtkWidget *window1;
//GtkWidget *affiche_etudiant;
GtkWidget *treeview;




//affiche_etudiant=lookup_widget(button,"window1");
//affiche_etudiant=create_window1();


//gtk_widget_show(affiche_etudiant);


treeview=lookup_widget(button,"treeview1");



afficher_resultat(treeview);

}


void
on_button_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *treeview;
GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget* p=lookup_widget(button,"treeview1");

gchar *pr;
selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
if (gtk_tree_selection_get_selected(selection,&model,&iter))
{ 
gtk_tree_model_get (model,&iter,0,&pr,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
    
delete_etudiant(pr);
   // afficher_resultat(treeview);

}
}


void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1,*w1;
GtkWidget *treeview1;

w1=lookup_widget(button,"window1");
window1=create_window1();
gtk_widget_show(window1);

gtk_widget_hide (w1);
treeview1=lookup_widget(window1,"treeview1");


afficher_resultat(treeview1);
}


void
on_treeview_recherche_nehdi_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_Modif_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *cin,*em,*ni,*lb;
int v=-1;
char nom[20];
char prenom[20];
char CIN[50];
char email[100];
char niv[20];
char type_chambre[50];
char num_chambre[50];
char num_tele[50];
char sexe[20];
date d;
etudiant e;
newe ne;

cin = lookup_widget (button,"entrycinnehdi");
em = lookup_widget (button,"entryemailnehdi");
ni = lookup_widget (button,"entrynivnehdi");








FILE *f;
//////////////////////////////////////////////////////////////////////////////////
f = fopen ("etudiant.txt", "r");


if (f!=NULL)
 {
  while (fscanf (f,"%s %s %s %s %s %s %s %s %s %d %d %d ",e.nom,e.prenom,e.CIN,e.email,e.niv,e.type_chambre,e.num_chambre,e.num_tele,e.sexe,&e.d.jour,&e.d.mois,&e.d.annee) != EOF)
  {
 
   if (strcmp(ne.cinnew,e.CIN)==0) 
      {
      v=1;
      }
     }
   lb=lookup_widget(button, "labelmodifmsgnehdi");
   gtk_label_set_text(GTK_LABEL(lb),"Modification faite avec succès");
     fclose (f);
  }

    


strcpy(ne.cinnew,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(ne.emailnew,gtk_entry_get_text(GTK_ENTRY(em)));
strcpy(ne.nivnew,gtk_entry_get_text(GTK_ENTRY(ni)));


update_etudiant(CIN,ne);

}


void
on_button_search_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
/*
GtkWidget *treeview7;
GtkWidget *pr;


char prenom[20];
etudiant e;
FILE *f;




pr=lookup_widget(button, "entryrecherchenehdi");



strcpy(prenom, gtk_entry_get_text(GTK_ENTRY(pr)));

search_etudiant(pr);
treeview7=lookup_widget(button,"treeview_recherche_nehdi");
afficher_recherche("treeview_recherche_nehdi");*/
}

