#ifndef AGENT_H_INCLUDED
#define AGENT_H_INCLUDED
#include <gtk/gtk.h>

typedef struct 
{
int jour;
int mois;
int annee;
}date;

typedef struct 
{
    char cinnew[50];
    char emailnew[50];
    char nivnew[50];

}newe;

typedef struct 
{
char nom[20];
char prenom[20];
char CIN[50];
char email[100];
char niv[20];
char type_chambre[50];
char num_chambre[50];
char num_tele[50];
char sexe[20];
date d;
}etudiant;


void add_etudiant(etudiant e);
void afficher_resultat(treeview1);
void delete_etudiant(char pr[]);
void update_etudiant(char CIN[],newe);
//void search_etudiant(char pr[]);
//void afficher_recherche(treeview_recherche_nehdi);
#endif
