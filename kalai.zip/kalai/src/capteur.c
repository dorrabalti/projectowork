#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capteur.h"
#include <gtk/gtk.h>

void ajouter(capteur C)
{

FILE *f=NULL;
if(verif_capteur(C.captID)==0)
{
f=fopen("capt.txt","a") ;

if(f!=NULL)

fprintf(f,"%s %s %d %d %s %s %d %d %d\n" , C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,C.d.j,C.d.m,C.d.a);

fclose(f);

}
else 
printf("error");

}

//////////////////////////////////////////////////////////////

void supp_id(char id[])
{
FILE *f;
    FILE *f1=NULL;
    capteur C;
    f=fopen("capt.txt","r");
    f1=fopen("tmp.txt","w");
    if(f!=NULL)
    {
        
        while(fscanf(f,"%s %s %d %d %s %s %d %d %d", C.captID ,
C.captType,&C.captValMax,&C.captValMin,C.captBlock,C.captEtage,&C.d.j,&C.d.m,&C.d.a)!=EOF)
        {
            if(strcmp(C.captID,id)!=0)
		   
	    {

                fprintf(f1,"%s %s %d %d %s %s %d %d %d\n", C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,C.d.j,C.d.m,C.d.a);
            }
                

            }
        fclose(f);
        fclose(f1);

        }

    remove ("capt.txt");
    rename ("tmp.txt","capt.txt");
}


void modifier_capt(capteur nvCapt)      
{
    capteur c;
    char id[20];

FILE *f;
FILE *tmp;

f=fopen("capt.txt","r");
tmp=fopen("tmp.txt","w"); // w tna7i elli tel9ah ou tekteb bejdid
while(fscanf(f, "%s %s %d %d %s %s %d %d %d", c.captID ,
c.captType,&c.captValMax,&c.captValMin,c.captBlock,c.captEtage,&c.d.j,&c.d.m,&c.d.a)!=EOF)
{
if (strcmp(c.captID,nvCapt.captID)==0)
{
fprintf(tmp,"%s %s %d %d %s %s %d %d %d\n" , c.captID ,
c.captType,nvCapt.captValMax,nvCapt.captValMin,nvCapt.captBlock,nvCapt.captEtage,c.d.j,c.d.m,c.d.a);
}
else
fprintf(tmp,"%s %s %d %d %s %s %d %d %d\n" , c.captID ,
c.captType,c.captValMax,c.captValMin,c.captBlock,c.captEtage,c.d.j,c.d.m,c.d.a);
}
fclose(f);
fclose(tmp);
remove("capt.txt");
rename("tmp.txt","capt.txt");

}
////////////////////////////////////////

void recherche_capteur(char Type[])
{
FILE *f=NULL;
FILE *f1=NULL;
capteur C;

f=fopen("capt.txt","r");// 
f1=fopen("resultat_recherche.txt","w"); // 
 if(f!=NULL)
    {
        
        while(fscanf(f,"%s %s %d %d %s %s %d %d %d", C.captID ,
C.captType,&C.captValMax,&C.captValMin,C.captBlock,C.captEtage,&C.d.j,&C.d.m,&C.d.a)!=EOF)
        {
            if(strcmp(C.captType,Type)==0)
		   
	    {

                fprintf(f1,"%s %s %d %d %s %s %d %d %d\n", C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,C.d.j,C.d.m,C.d.a);
            }
else 
printf("erreur \n");
                

            }
}
close(f);
close(f1);
}

//////////////////////////////////////
int verif_capteur(char *ID)
{
capteur C;
FILE*f=NULL;
int existe=0;
f=fopen("capt.txt","r");
if(f!=NULL)
{
   while(fscanf(f, "%s %s  %d %d %s %s %d %d %d" , C.captID ,
C.captType,&C.captValMax,&C.captValMin,C.captBlock,C.captEtage,&C.d.j,&C.d.m,&C.d.a)!=EOF)
{
if(strcmp(C.captID,ID)==0)

return 1;  //id existe deja

}
fclose(f);
return 0;
}
}
///



enum
{
	E_ID,
        E_TYPE,
	E_VALEUR_MAX,
	E_VALEUR_MIN,
	E_BLOCK,
	E_ETAGE,
	E_JOUR,
	E_MOIS,
	E_ANNEE,
	COLUMNS
};

//////////////

void afficher(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	char captID [20];
	char captType [20] ;
	int captValMin;
	int captValMax;
	char captBlock[20] ;
	char captEtage[20];
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captID", renderer, "text",E_ID, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captType", renderer, "text",E_TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMax", renderer, "text",E_VALEUR_MAX, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMin", renderer, "text",E_VALEUR_MIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captBlock", renderer,"text",E_BLOCK, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captEtage", renderer,"text",E_ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",E_JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",E_MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",E_ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,  G_TYPE_INT, G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
f=fopen("capt.txt","r");
if(f==NULL)
{
return;
}
else
{
 f = fopen("capt.txt","r");
	while(fscanf(f,"%s %s %d %d %s %s %d %d %d",captID,captType,&captValMax,&captValMin,captBlock,captEtage,&jour,&mois,&annee)!=EOF)
	{
         
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, E_ID, captID, E_TYPE, captType, E_VALEUR_MAX, captValMax, E_VALEUR_MIN, captValMin, E_BLOCK, captBlock,E_ETAGE, captEtage, E_JOUR, jour, E_MOIS, mois, E_ANNEE, annee,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}


////////////////

void afficher_recherche(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	char captID [20];
	char captType [20] ;
	int captValMin;
	int captValMax;
	char captBlock[20] ;
	char captEtage[20];
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captID", renderer, "text",E_ID, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captType", renderer, "text",E_TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMax", renderer, "text",E_VALEUR_MAX, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMin", renderer, "text",E_VALEUR_MIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captBlock", renderer,"text",E_BLOCK, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captEtage", renderer,"text",E_ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",E_JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",E_MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",E_ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,  G_TYPE_INT, G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
f=fopen("resultat_recherche.txt","r");
if(f==NULL)
{
return;
}
else
{
 f = fopen("resultat_recherche.txt","r");
	while(fscanf(f,"%s %s %d %d %s %s %d %d %d",captID,captType,&captValMax,&captValMin,captBlock,captEtage,&jour,&mois,&annee)!=EOF)
	{
         
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, E_ID, captID, E_TYPE, captType, E_VALEUR_MAX, captValMax, E_VALEUR_MIN, captValMin, E_BLOCK, captBlock,E_ETAGE, captEtage, E_JOUR, jour, E_MOIS, mois, E_ANNEE, annee,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}

//////////////////
enum
{	
	EETAGE,
	EJOUR,
	EMOIS,
	ETEMP,
	COLUMN
};


/////////////////////////////////////
void capteur_defectueux(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	int captEtage;
	int jour;
	int mois;
	float temperature;
	store=NULL;

FILE *f3;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captEtage", renderer,"text",EETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",EMOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("temperature", renderer,"text",ETEMP, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMN, G_TYPE_INT, G_TYPE_INT,  G_TYPE_INT, G_TYPE_FLOAT);
f3=fopen("temperature.txt","r");
if(f3==NULL)
{
return;
}
else
{
 f3 = fopen("temperature.txt","r");
	while(fscanf(f3,"%d %d %d %f",&captEtage,&jour,&mois,&temperature)!=EOF)
	{
        if ((temperature<10.00) || (temperature>30.00)) 
        { 
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, EETAGE, captEtage, EJOUR, jour, EMOIS, mois, ETEMP, 	temperature,-1);		
	}
        }
	fclose(f3);
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}


