#include <gtk/gtk.h>


void
on_button3_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_suprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_annuler_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_eau_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mouv_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_3_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_4_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_tempe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_fumee_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_etage1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_rdc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_supp_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);


void
on_radiobutton_1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_3_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_2m_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_3m_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_Mrdc_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_1m_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkButton       *objet,
                                        gpointer         user_data);


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button5_modifier_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button6_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_mdT_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_mdf_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_mde_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_mdm_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_mdrdc_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton9_md1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_md2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_md3_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_md4_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_retour_af_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_defectueu_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_defectueux_activate         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifierA_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouterA_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_defectueux_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_defectueux_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_Rechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_deff_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_defretour_clicked            (GtkButton       *button,
                                        gpointer         user_data);
