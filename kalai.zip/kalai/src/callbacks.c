#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
int x,e,m,tp,k;	

void
on_radiobutton_eau_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ x=3;}

}


void
on_radiobutton_mouv_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ x=4;}
}


void
on_radiobutton_2_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ e=3;}

}


void
on_radiobutton_3_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ e=4;}

}


void
on_radiobutton_4_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ e=5;}

}


void
on_radiobutton_tempe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ x=1;}

}


void
on_radiobutton_fumee_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ x=2;}

}


void
on_radiobutton_etage1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ e=2;}
}


void
on_radiobutton_rdc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ e=1;}

}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *sortie;
GtkWidget *Id;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *Vmin;
GtkWidget *Vmax;
GtkWidget *Combobox_bloc;
capteur c;

sortie=lookup_widget(objet_graphique,"validation");
Combobox_bloc=lookup_widget(objet_graphique,"combobox_bloc");
Vmax= lookup_widget(objet_graphique,"spinbutton_max");
Vmin= lookup_widget(objet_graphique,"spinbutton_min");
annee= lookup_widget(objet_graphique,"spinbutton_annee");
mois= lookup_widget(objet_graphique,"spinbutton_mois");
jour= lookup_widget(objet_graphique,"spinbutton_jour");
Id= lookup_widget(objet_graphique,"entry_id");
strcpy(c.captID, gtk_entry_get_text(GTK_ENTRY(Id)));
c.d.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
c.d.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c.d.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));


c.captValMax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Vmax));
c.captValMin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Vmin));
strcpy(c.captBlock,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox_bloc)));

switch(x)
{
case 1:
strcpy(c.captType,"Temperature");
break;
case 2:
strcpy(c.captType,"fumee");
break;
case 3:
strcpy(c.captType,"debit_deau");
break;
case 4:
strcpy(c.captType,"mouvement");
break;

}
switch(e)
{
case 1:
strcpy(c.captEtage,"RDC");
break;
case 2:
strcpy(c.captEtage,"1er_etage");
break;
case 3:
strcpy(c.captEtage,"2eme_etage");
break;
case 4:
strcpy(c.captEtage,"3eme_etage");
break;
case 5:
strcpy(c.captEtage,"4eme_etage");
break;
}

ajouter(c);
gtk_label_set_text(GTK_LABEL(sortie),"capteur bien ajouté");


}

void
on_radiobutton_2m_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ m=3;}


}


void
on_radiobutton_3m_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ m=4;}

}


void
on_radiobutton_Mrdc_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ m=1;}

}


void
on_radiobutton_1m_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{ m=2;}

}


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkTreeModel *model;
GtkTreeSelection *selection;
GtkTreeIter iter;
GtkWidget *p;
GtkWidget *label;
gchar *id;
p=lookup_widget(objet,"treeview1");
selection=gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
if(gtk_tree_selection_get_selected(selection,&model,&iter))
{gtk_tree_model_get(model,&iter,0,&id,-1);
gtk_list_store_remove(GTK_LIST_STORE(model),&iter);}
supp_id(id);
afficher(p);
}

void
on_button5_modifier_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *vmax,*vmin,*block,*rech, *sortie;

capteur p;


vmax=lookup_widget(objet,"spinbutton5");
vmin=lookup_widget(objet,"spinbutton4");

block=lookup_widget(objet,"combobox1");


rech=lookup_widget(objet,"entry2");
sortie=lookup_widget(objet,"labelModif");


strcpy(p.captBlock,gtk_combo_box_get_active_text(GTK_COMBO_BOX(block)));

strcpy(p.captID,gtk_entry_get_text(GTK_ENTRY(rech)));


p.captValMax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(vmax));
p.captValMin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(vmin));

switch(k)
{
case 0:
strcpy(p.captEtage,"RDC");
break;
case 1:
strcpy(p.captEtage,"1er_etage");
break;
case 2:
strcpy(p.captEtage,"2eme_etage");
break;
case 3:
strcpy(p.captEtage,"3eme_etage");
break;
case 4:
strcpy(p.captEtage,"4eme_etage");
break;
}
modifier_capt(p);

gtk_label_set_text(GTK_LABEL(sortie),"capteur bien modifié");

GtkWidget *fenetreModif;
GtkWidget *treeview1;
GtkWidget *fenetreAfficher;
fenetreModif=lookup_widget(objet,"modifier");
gtk_widget_destroy(fenetreModif);
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreAfficher= create_fenetre_afficher();

gtk_widget_show(fenetreAfficher);
treeview1 = lookup_widget(fenetreAfficher,"treeview1");
afficher(treeview1);
}


void
on_button6_retour_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreModif;
GtkWidget *treeview1;
GtkWidget *fenetreAfficher;
fenetreModif=lookup_widget(objet,"modifier");
gtk_widget_destroy(fenetreModif);
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreAfficher= create_fenetre_afficher();

gtk_widget_show(fenetreAfficher);
treeview1 = lookup_widget(fenetreAfficher,"treeview1");
afficher(treeview1);
}


void
on_button4_chercher_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *type1,*type2,*type3,*type4,*type5,*vmax,*vmin,*block,*etage,*rech;
capteur c;
capteur p;

char reche[200];


type1=lookup_widget(objet,"radiobutton_mdrdc");
type2=lookup_widget(objet,"radiobutton_md1");
type3=lookup_widget(objet,"radiobutton_md2");
type4=lookup_widget(objet,"radiobutton_md3");
type5=lookup_widget(objet,"radiobutton_md4");
vmax=lookup_widget(objet,"spinbutton5");
vmin=lookup_widget(objet,"spinbutton4");
block=lookup_widget(objet,"combobox1");
rech=lookup_widget(objet,"entry2");

int j=0;
char Tab[8];


strcpy(reche,gtk_entry_get_text(GTK_ENTRY(rech)));

FILE *f=NULL;
int v=1;
f=fopen("capt.txt","r");
while(fscanf(f,"%s %s %d %d %s %s %d %d %d",c.captID,c.captType,&c.captValMax,&c.captValMin,c.captBlock,c.captEtage,&c.d.j,&c.d.m,&c.d.a)!=EOF)
        {
	if( strcmp(reche,c.captID)==0){
			
			v=0;
			
			strcpy(p.captBlock,c.captBlock);
			strcpy(p.captEtage,c.captEtage);
			p.captValMax=c.captValMax;
			p.captValMin=c.captValMin;
			
			
			
			
	}
	else 
		{
		gtk_entry_set_text (vmax,"");
		gtk_entry_set_text (vmin,"");
		gtk_entry_set_text (block,"");
		gtk_entry_set_text (etage,"");

}
}
if(v==0)
{
	
	
	if(strcmp(p.captEtage,"RDC")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type1),TRUE);
	}
	else if(strcmp(p.captEtage,"1er_etage")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type2),TRUE);
	}
	else if(strcmp(p.captEtage,"2eme_etage")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type3),TRUE);
	}
	else if(strcmp(p.captEtage,"3eme_etage")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type4),TRUE);
	}
	else if(strcmp(p.captEtage,"4eme_etage")==0)
	{
	gtk_toggle_button_set_active(GTK_RADIO_BUTTON (type5),TRUE);
	}
	
	
	gtk_spin_button_set_value(vmax,p.captValMax);
	gtk_spin_button_set_value(vmin,p.captValMin);
	
}

}


void
on_radiobutton1_mdT_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
tp=0;

}


void
on_radiobutton3_mdf_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
tp=1;

}


void
on_radiobutton4_mde_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
tp=2;
}


void
on_radiobutton6_mdm_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
tp=3;
}


void
on_radiobutton8_mdrdc_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
k=0;

}


void
on_radiobutton9_md1_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
k=1;
}


void
on_radiobutton_md2_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
k=2;
}


void
on_radiobutton_md3_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
k=3;
}


void
on_radiobutton_md4_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
k=4;
}


void
on_button_modifierA_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetreModif;
GtkWidget *fenetreAfficher;
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreModif=lookup_widget(objet,"modifier");
gtk_widget_destroy(fenetreAfficher);
fenetreModif=create_modifier();
gtk_widget_show(fenetreModif);

}


void
on_button_ajouterA_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreAjout;
GtkWidget *fenetreAfficher;
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreAjout=lookup_widget(objet,"ajouter");
gtk_widget_destroy(fenetreAfficher);
fenetreAjout= create_ajouter();
gtk_widget_show(fenetreAjout);

}



void
on_button_defectueux_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreDef;
GtkWidget *fenetreAfficher;
GtkWidget *treeview;

fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetreAfficher);
fenetreDef=lookup_widget(objet,"defectueux");
fenetreDef= create_defectueux();
gtk_widget_show(fenetreDef);

treeview= lookup_widget(fenetreDef,"treeview3");
capteur_defectueux(treeview);
}


void
on_button_Rech_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetreRech;
GtkWidget *fenetreAfficher;
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreRech=lookup_widget(objet,"fenetre_Rechercher");
gtk_widget_destroy(fenetreAfficher);
fenetreRech= create_fenetre_Rechercher();
gtk_widget_show(fenetreRech);

}


void
on_button2_Rechercher_clicked          (GtkButton       *objet,
                                        gpointer         user_data)
{
char Type[20];
GtkWidget *rech,*treeview, *sortie;

rech= lookup_widget(objet,"entryRecherche");
treeview = lookup_widget(objet,"treeview2");
sortie=lookup_widget(objet,"labelRe");
strcpy(Type, gtk_entry_get_text(GTK_ENTRY(rech)));
recherche_capteur(Type);

gtk_label_set_text(GTK_LABEL(sortie),"done");
afficher_recherche(treeview);


}

void
on_button_afficher_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetreAjout;
GtkWidget *treeview1;
GtkWidget *fenetreAfficher;
fenetreAjout=lookup_widget(objet,"ajouter");
gtk_widget_destroy(fenetreAjout);
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreAfficher= create_fenetre_afficher();

gtk_widget_show(fenetreAfficher);
treeview1 = lookup_widget(fenetreAfficher,"treeview1");
afficher(treeview1);
}
void
on_button5_Retour_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *fenetreRech;
GtkWidget *fenetreAfficher;
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
fenetreRech=lookup_widget(objet,"fenetre_Rechercher");
gtk_widget_destroy(fenetreRech);
fenetreAfficher= create_fenetre_afficher();
gtk_widget_show(fenetreAfficher);
treeview1 = lookup_widget(fenetreAfficher,"treeview1");
afficher(treeview1);


}





void
on_button_defretour_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *defectueux;
GtkWidget *fenetreAfficher;
fenetreAfficher= lookup_widget(objet,"fenetre_afficher");
defectueux=lookup_widget(objet,"defectueux");
gtk_widget_destroy(defectueux);
fenetreAfficher= create_fenetre_afficher();
gtk_widget_show(fenetreAfficher);
treeview1 = lookup_widget(fenetreAfficher,"treeview1");
afficher(treeview1);
}

